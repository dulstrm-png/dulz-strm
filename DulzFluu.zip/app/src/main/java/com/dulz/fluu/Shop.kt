package com.dulz.fluu

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.UUID

/**
 * Kode unlock, toko premium, dan status fitur terbuka.
 *
 * Dua mode:
 *  - Online : "backend" di assets/config.json diisi URL Google Apps Script (lihat folder backend).
 *             Kode benar-benar sekali pakai di semua HP, pesanan masuk ke email admin,
 *             dan kode muncul otomatis di aplikasi setelah admin menyetujui.
 *  - Offline: backend kosong. Kode dicek lewat daftar hash di assets/codes.json dan
 *             dicatat terpakai di HP ini saja. Pesanan dikirim lewat aplikasi email.
 */
object Shop {

    const val PREMIUM = "PREMIUM"
    private const val SALT = "dulz|"

    private var cfg: JSONObject? = null

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("dulz", Context.MODE_PRIVATE)

    fun config(ctx: Context): JSONObject {
        cfg?.let { return it }
        val j = try {
            JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
        } catch (e: Exception) {
            JSONObject()
        }
        cfg = j
        return j
    }

    fun backend(ctx: Context): String = config(ctx).optString("backend", "").trim()
    fun adminEmail(ctx: Context): String = config(ctx).optString("admin_email", "dulstrm@gmail.com")

    fun deviceId(ctx: Context): String {
        val p = prefs(ctx)
        var id = p.getString("device_id", null)
        if (id == null) {
            id = UUID.randomUUID().toString().replace("-", "").take(16)
            p.edit().putString("device_id", id).apply()
        }
        return id
    }

    // ------------------------------------------------------------ Fitur terbuka

    fun unlocked(ctx: Context): Set<String> =
        (prefs(ctx).getString("unlocked", "") ?: "").split(",").filter { it.isNotBlank() }.toSet()

    fun has(ctx: Context, id: String): Boolean {
        val s = unlocked(ctx)
        return PREMIUM in s || id in s
    }

    private fun grant(ctx: Context, type: String) {
        val s = unlocked(ctx).toMutableSet()
        s.add(type)
        prefs(ctx).edit().putString("unlocked", s.joinToString(",")).apply()
    }

    // ------------------------------------------------------------ Kode

    fun norm(code: String): String = code.uppercase().filter { it.isLetterOrDigit() }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun localTable(ctx: Context): JSONObject = try {
        JSONObject(ctx.assets.open("codes.json").bufferedReader().use { it.readText() }).getJSONObject("codes")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun fail(msg: String) = JSONObject().put("ok", false).put("msg", msg)

    /** Menukar kode. Dipanggil dari thread latar belakang. */
    fun redeem(ctx: Context, raw: String): JSONObject {
        val code = norm(raw)
        if (code.length < 8) return fail("Kode tidak valid")

        val url = backend(ctx)
        if (url.isNotEmpty()) {
            val r = http("$url?a=redeem&code=${enc(code)}&dev=${enc(deviceId(ctx))}")
            if (r.optBoolean("ok")) grant(ctx, r.optString("type", PREMIUM))
            return r
        }

        val h = sha(SALT + code)
        val type = localTable(ctx).optString(h, "")
        if (type.isEmpty()) return fail("Kode salah")
        val used = prefs(ctx).getStringSet("used_codes", emptySet()) ?: emptySet()
        if (h in used) return fail("Kode ini sudah pernah dipakai")
        prefs(ctx).edit().putStringSet("used_codes", used + h).apply()
        grant(ctx, type)
        return JSONObject().put("ok", true).put("type", type)
    }

    // ------------------------------------------------------------ Pesanan

    fun orderCreate(ctx: Context, name: String, contact: String): JSONObject {
        val url = backend(ctx)
        if (url.isNotEmpty()) {
            return http(
                "$url?a=order&name=${enc(name)}&contact=${enc(contact)}&dev=${enc(deviceId(ctx))}&amount=${config(ctx).optInt("price", 8000)}"
            ).also { if (it.optBoolean("ok")) it.put("mode", "online") }
        }
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val id = "DZ" + (1..6).map { chars.random() }.joinToString("")
        return JSONObject().put("ok", true).put("order", id).put("mode", "email")
    }

    fun orderStatus(ctx: Context, order: String): JSONObject {
        val url = backend(ctx)
        if (url.isEmpty()) return fail("Mode email: tunggu admin mengirim kode")
        return http("$url?a=status&order=${enc(order)}&dev=${enc(deviceId(ctx))}")
    }

    // ------------------------------------------------------------ HTTP

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun http(u: String): JSONObject = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        val body = (if (c.responseCode in 200..299) c.inputStream else c.errorStream)
            .bufferedReader().use { it.readText() }
        c.disconnect()
        JSONObject(body)
    } catch (e: Exception) {
        fail("Tidak bisa terhubung ke server. Periksa internet")
    }
}
